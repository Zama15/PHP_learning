<?php 
namespace framework\models;

use framework\classes\database;

class Model extends DataBase {
  public function __construct() {
    parent::__construct();
  }
}
?>
