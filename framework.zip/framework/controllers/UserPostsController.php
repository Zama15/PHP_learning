<?php 
namespace framework\controllers;

use framework\classes\csrf;
use framework\classes\view;
use framework\controllers\auth\SessionController;
use framework\models\posts;

class UserPostsController extends BaseController {
  public function __construct() {
    parent::__construct();
  }

  public function index() {
    $session = SessionController::sessionCheck();

    $response = [
      'title' => 'Home',
      'code' => 200,
      'session' => $session ?? ['valid' => false]
    ];

    if (is_null($session)) {
      View::render('home', $response);
      exit();
    }

    $data['title'] = 'My Posts';
    $data['message'] = 'My Posts';

    View::render('myposts', $response);
  }

  public function getMyPosts($params = null) {
    $posts = new Posts();
    $result = $posts->getUserPosts($params);

    echo $result;
  }

  public function newPost() {
    $csrf = new Csrf();
    $session = SessionController::sessionCheck() ?? ['valid' => false];
    
    $response = [
      'title' => 'New Post',
      'code' => 200,
      'session' => $session,
      'csrf' => $csrf->get_token()
    ];

    view::render('newpost', $response);
  }
}
?>
