<?php 
namespace framework\controllers;

class BaseController {
  public function __construct() {
    
  }
}
?>
