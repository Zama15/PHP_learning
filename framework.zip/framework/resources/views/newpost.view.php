<?php
  include_once LAYOUTS . 'header.php';
  
  setHeader($d);
  $d = as_obj($d);
?>


<?php
  include_once LAYOUTS . 'footer.php';
  setFooter($d, 'myposts.js');
?>
<?php closeFooter(); ?>
