<?php 
function as_obj($array) {
  return json_decode(json_encode($array));
}
?>
