<?php 
namespace Framework;

use Framework\App;

require_once __DIR__ . '/../app.php';

App::run();
?>
